#!/usr/bin/env python
"""Wrapper to run setup.py using setuptools."""
import setuptools
execfile('setup.py')
