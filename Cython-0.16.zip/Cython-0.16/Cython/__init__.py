__version__ = "0.16"

# Void cython.* directives (for case insensitive operating systems).
from Cython.Shadow import *
